
export const emoji = {
    // blacklist
    bl: '<:premiumemoji_12:1359134089030139975>',
    // general
    heart: '<:white_heart:1360304441416220742>',
    check: '<:check:1347771218194862170>',
    cross: '<:cross:1347771324961001492>',
    info: '<:neroxinfo:1359021495954964512>',
    info1: '<:info11emoji_13:1359134171842216117>',
    timer: '<:cooldown:1347771550744711168>',
    warn: '<:warn:1347771698908364820>',
    // player controls
    previous: '<:previous:1347772837737533494>',
    pause: '<:Pause:1347772920872697906>',
    resume: '<:resume:1347772962731982900>',
    next: '<:next:1347773081686376510>',
    stop: '<:music_stop:1347773131695194214>',
    autoplay: '<:Autoplay:1347773192617459833>',
    // premium
    premium: '<:premiumemoji_12:1359134089030139975>',
    prem: '<:premiumemoji_12:1359134089030139975>',
};
/**@codeStyle - https://google.github.io/styleguide/tsguide.html */