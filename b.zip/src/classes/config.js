export const config = {
  token: "MTM0ODU5MDg1MTQzNzM2NzMyNw.Gh0upu.OxH2BaUFUSPB-1WxWohuJqL97i0omp-kAFF_nc",
  owners: ["1349404026965463072", "991517803700027443"],
  admins: ["991517803700027443"],
  prefix: "&",
  links: {
      support: "https://discord.gg/p6nXDJMeyc"
  },
  backup: "1347901024026759278",
  webhooks: {
    logs: "https://discord.com/api/webhooks/1350321779947737128/6-tE0Eoc9k0BZ6iQywIANG0DH3UUfy6-jbcbMRGntwc-lDmfSWTvzIAkeul69nyVn2Ho",
    serveradd: "https://discord.com/api/webhooks/1350322345427861545/C141joOk07meA489fGR5Vzm1If9AdpBQ39X_x1pLTfbh9zZ1A2F2hnLtu75-XKejiXSq",
      serverchuda: "https://discord.com/api/webhooks/1350321908435910687/InbAw3EQyIIpRjMa8HSAC9C3QfyslkSgft7j_1OzJPzHNesyNbBaM4je9h-F-zh5-Kpz",
    playerLogs: "https://discord.com/api/webhooks/1350322236682141716/lsdjwgvRHu36Ueu6KnSS_3AxoyD0gngxmkfLEL-nwmxZAI2ss2ZLnOLCQbpPoUtQx_w5"
  }
};